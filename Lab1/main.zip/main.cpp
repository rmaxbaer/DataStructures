#include "TodoList.h"
#include "TodoListInterface.h"

#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

int main(int argc, char* argv[]){
    
    string command = argv[1]; 
    string taskDay = "DAY";
    string taskName = "TASK";
    TodoList newTask;
    
    
    if (command == "add"){
        //add an item to the todo list
        taskDay = argv[2];
        taskName = argv[3];
        
        newTask.add(taskDay, taskName);
    }
    else if (command == "remove"){
        taskName = argv[2];
        newTask.remove(taskName);
    }
    else if (command == "printList"){
        newTask.printTodoList();
    }
    else if (command == "printDay"){
        taskDay = argv[2];
        newTask.printDaysTasks(taskDay);
    }
    else {
        cout << "Command: \"" << command << "\" not found." << endl;
    }
    
    return 0;
}